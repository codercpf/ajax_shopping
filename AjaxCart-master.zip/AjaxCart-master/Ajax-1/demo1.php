<?php
    echo "我不是二手科学家，我要像jason一样，能文能武";
    
    echo "<pre>";
    //var_dump($_GET);
    var_dump($_POST);
    echo "</pre>";